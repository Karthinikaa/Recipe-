import "./style.scss";

export { Login } from "./loginpage";
export { Register } from "./register";