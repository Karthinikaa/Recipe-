To test

Python root
curl --location 'http://127.0.0.1:5000/'

Python Recipe in sub file
curl --location 'http://127.0.0.1:5000/toprate'
